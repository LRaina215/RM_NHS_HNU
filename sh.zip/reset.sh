#!/bin/bash

# 脚本名称：reset.sh

# 运行lsusb命令并筛选出包含特定ID的行
device_info=$(lsusb | grep 'ID 0ffe:0001' | awk '{print $2, $4}' | tr -d ':')

# 检查是否找到设备
if [ -z "$device_info" ]; then
  echo "No device found with ID 0ffe:0001"
  exit 1
fi

# 读取总线号和设备号
bus=$(echo $device_info | cut -d' ' -f1)
device=$(echo $device_info | cut -d' ' -f2)

# 重置USB设备
sudo ./usbreset "/dev/bus/usb/$bus/$device"
