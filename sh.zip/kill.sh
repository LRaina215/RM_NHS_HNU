#!/bin/bash

echo "Stopping autoaim services..."

# 停止hik_camera_node进程
PIDS=$(ps -ef | grep "hik_camera.launch.py" | grep -v grep | awk '{print $2}')
if [ "$PIDS" != "" ]; then
    echo "Stopping hik_camera_node..."
    kill -9 $PIDS
fi

# 停止model.launch.py进程
PIDS=$(ps -ef | grep "model.launch.py" | grep -v grep | awk '{print $2}')
if [ "$PIDS" != "" ]; then
    echo "Stopping model.launch.py..."
    kill -9 $PIDS
fi

# 停止sentry_up_serial_launch.py进程
PIDS=$(ps -ef | grep "sentry_up_serial_launch.py" | grep -v grep | awk '{print $2}')
if [ "$PIDS" != "" ]; then
    echo "Stopping sentry_up_serial_launch.py..."
    kill -9 $PIDS
fi

# 停止auto_aim_bringup.py进程
PIDS=$(ps -ef | grep "auto_aim.launch.py" | grep -v grep | awk '{print $2}')
if [ "$PIDS" != "" ]; then
    echo "Stopping auto_aim_bringup.py..."
    kill -9 $PIDS
fi

# 停止auto_aim.sh进程
PIDS=$(ps -ef | grep "auto_aim.sh" | grep -v grep | awk '{print $2}')
if [ "$PIDS" != "" ]; then
    echo "Stopping auto_aim.sh..."
    kill -9 $PIDS
fi

# 停止rqt进程 Debug!!!!
PIDS=$(ps -ef | grep "rqt" | grep -v grep | awk '{print $2}')
if [ "$PIDS" != "" ]; then
    echo "Stopping rqt..."
    kill -9 $PIDS
fi

echo "All autoaim services have been stopped."
