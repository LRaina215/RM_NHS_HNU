#!/bin/bash

# 脚本名称：run_plotjuggler.sh

# 切换到指定目录
cd zxzzb/

# 源setup.bash文件
source install/setup.bash
source install/setup.bash
source install/setup.bash


# 运行plotjuggler
ros2 run plotjuggler plotjuggler
