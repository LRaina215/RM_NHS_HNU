#! /bin/bash

echo "autoaim start!"

export ROS_LOG_DIR=/home/robomaster/log

. /opt/ros/galactic/setup.sh
. /home/robomaster/zxzzb/install/setup.sh

#sleep

#echo 1 | sudo systemctl stop nav_service.service
#. /home/robomaster/kill_nav.sh

# 检查rqt是否已经在运行，如果没有则启动   Debug!!!!
PIDS=$(ps -ef | grep "rqt" | grep -v grep | awk '{print $2}')
if [ "$PIDS" = "" ]; then
    echo "Starting rqt..."
    gnome-terminal -- rqt &
fi

while true; do
	#camera
	PIDS=`ps -ef | grep "hik_camera.launch.py" | grep -v grep | awk '{print $2}'`
	if [ "$PIDS" != "" ]; 
	then
		echo "hik_camera_node is running!"
	else
			
		echo "start hik_camera_node ! ! ! ! !"
		gnome-terminal -- ros2 launch hik_camera hik_camera.launch.py &
	fi
	#model
	PIDS=`ps -ef | grep "model.launch.py" | grep -v grep | awk '{print $2}'`
	if [ "$PIDS" != "" ]; then
		echo "model.launch.py is running!"
	else
		echo "start model.launch.py ! ! ! ! !"
		gnome-terminal -- ros2 launch rm_description model.launch.py &
	fi
	#protocol
	PIDS=`ps -ef | grep "sentry_up_serial_launch.py" | grep -v grep | awk '{print $2}'`
	if [ "$PIDS" != "" ]; then
		echo "sentry_up_serial_launch.py is running!"
	else
		echo "sentry_up_serial_launch.py ! ! ! ! !"
		gnome-terminal --  ros2 launch bubble_protocol sentry_up_serial_launch.py &
	fi
	#auto_aim
	PIDS=`ps -ef | grep "auto_aim.launch.py" | grep -v grep | awk '{print $2}'`
	if [ "$PIDS" != "" ]; then
		echo "auto_aim_bringup.py is running!"
	else
		echo "start auto_aim_bringup.py ! ! ! ! !"
		gnome-terminal -- ros2 launch auto_aim_bringup auto_aim.launch.py &
	fi
	
	sleep 5
done	

